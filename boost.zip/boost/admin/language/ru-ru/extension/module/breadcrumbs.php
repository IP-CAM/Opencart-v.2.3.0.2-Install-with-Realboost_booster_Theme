<?php
/**
* @module   BreadCrumbs
* @author   catcherochek
* @created  09.07.2019 03:39
*/

$_ = [
    'heading_title'                  => 'BreadCrumbs',
    'text_module'                    => 'Модули',
    'text_success'                   => 'Успешно: Вы изменили настройки модуля!',
    't_status'                       => 'Статус',
    'error_permission'               => 'Внимание: у Вас недостаточно прав, для редактирования модуля!',
];