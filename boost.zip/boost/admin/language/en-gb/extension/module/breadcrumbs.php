<?php
/**
 * @module   BreadCrumbs
 * @author   catcherochek
 * @created  09.07.2019 03:39
 */

$_ = [
    'heading_title'                  => 'BreadCrumbs',
    'text_module'                    => 'Modules',
    'text_success'                   => 'Success: You have modified module!',
    't_status'                       => 'Status',
    'error_permission'               => 'Warning: You do not have permission to modify module!',
];